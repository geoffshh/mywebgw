<?php
session_start();
require_once 'db.php';

// OPTIONAL: proteksi admin
if (!isset($_SESSION['logged_in']) || $_SESSION['user_level'] !== 'admin') {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit;
}

header('Content-Type: application/json');

// ====== PARAMETER ======
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$role   = $_GET['role'] ?? '';
$search = $_GET['search'] ?? '';

// ====== FILTER ======
$where = "WHERE 1=1";

if ($role !== '') {
    $role = mysqli_real_escape_string($conn, $role);
    $where .= " AND level='$role'";
}

if ($search !== '') {
    $search = mysqli_real_escape_string($conn, $search);
    $where .= " AND (username LIKE '%$search%' OR email LIKE '%$search%')";
}

// ====== TOTAL DATA ======
$totalQ = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users $where");
$total  = mysqli_fetch_assoc($totalQ)['total'];
$pages  = ceil($total / $limit);

// ====== DATA USER ======
$sql = "
SELECT 
  id,
  username,
  email,
  level AS role,
  created_at
FROM users
$where
ORDER BY id DESC
LIMIT $limit OFFSET $offset
";

$q = mysqli_query($conn, $sql);

$users = [];
while ($row = mysqli_fetch_assoc($q)) {
    $row['status'] = 'active';       // default
    $row['profile_pic'] = null;      // placeholder
    $users[] = $row;
}

// ====== RESPONSE ======
echo json_encode([
    'success' => true,
    'users' => $users,
    'pagination' => [
        'page' => $page,
        'pages' => $pages
    ]
]);
