<?php
// update_product_status.php
header('Content-Type: application/json');
session_start();
require_once 'db.php';

if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$product_id = intval($_POST['product_id'] ?? 0);
$new_status = $_POST['status'] ?? '';

if (!$product_id || !in_array($new_status, ['active', 'inactive'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit;
}

// Ambil data produk
$stmt = mysqli_prepare($conn, "
    SELECT status, created_by 
    FROM products 
    WHERE id = ?
");
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$product = mysqli_fetch_assoc($result);

if (!$product) {
    echo json_encode(['success' => false, 'message' => 'Produk tidak ditemukan']);
    exit;
}

// ❌ Draft tidak boleh ditoggle
if ($product['status'] === 'draft') {
    echo json_encode(['success' => false, 'message' => 'Produk draft tidak bisa diubah status']);
    exit;
}

// Cek role
$is_admin = isset($_SESSION['level']) && $_SESSION['level'] === 'admin';
$user_id  = $_SESSION['user_id'] ?? 0;

// ❌ Bukan admin & bukan owner
if (!$is_admin && $product['created_by'] != $user_id) {
    echo json_encode(['success' => false, 'message' => 'Akses ditolak']);
    exit;
}

// Update status
$update = mysqli_prepare($conn, "
    UPDATE products 
    SET status = ?, updated_at = NOW()
    WHERE id = ?
");
mysqli_stmt_bind_param($update, "si", $new_status, $product_id);

if (mysqli_stmt_execute($update)) {
    echo json_encode([
        'success' => true,
        'message' => 'Status produk diperbarui',
        'status'  => $new_status
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Gagal update status'
    ]);
}
