<?php
// delete_product.php - FIXED VERSION
session_start();
require_once 'db.php';

// TURN OFF ERROR DISPLAY IN PRODUCTION, but enable for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

// Debug logging
file_put_contents('../debug.log', date('Y-m-d H:i:s') . " - Delete request\n", FILE_APPEND);

// Check login
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit();
}

// Only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'POST method required']);
    exit();
}

// Get product ID
$product_id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
file_put_contents('../debug.log', "Product ID: $product_id\n", FILE_APPEND);

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
    exit();
}

// Initialize variables
$image_url = '';
$error = '';

try {
    // 1. CHECK IF PRODUCT EXISTS AND GET IMAGE URL
    $check_sql = "SELECT image_url FROM products WHERE id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    
    if (!$check_stmt) {
        throw new Exception('Prepare failed: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($check_stmt, "i", $product_id);
    
    if (!mysqli_stmt_execute($check_stmt)) {
        throw new Exception('Execute failed: ' . mysqli_stmt_error($check_stmt));
    }
    
    mysqli_stmt_bind_result($check_stmt, $image_url);
    $has_product = mysqli_stmt_fetch($check_stmt);
    mysqli_stmt_close($check_stmt);
    
    if (!$has_product) {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        exit();
    }
    
    file_put_contents('../debug.log', "Image URL: $image_url\n", FILE_APPEND);
    
    // 2. DELETE IMAGE FILE IF EXISTS
    if (!empty($image_url) && $image_url !== 'NULL') {
        $image_path = '../' . $image_url;
        file_put_contents('../debug.log', "Image path: $image_path\n", FILE_APPEND);
        
        if (file_exists($image_path)) {
            if (unlink($image_path)) {
                file_put_contents('../debug.log', "Image deleted successfully\n", FILE_APPEND);
            } else {
                file_put_contents('../debug.log', "Failed to delete image\n", FILE_APPEND);
            }
        } else {
            file_put_contents('../debug.log', "Image file not found\n", FILE_APPEND);
        }
    }
    
    // 3. DELETE FROM DATABASE
    $delete_sql = "DELETE FROM products WHERE id = ?";
    $delete_stmt = mysqli_prepare($conn, $delete_sql);
    
    if (!$delete_stmt) {
        throw new Exception('Delete prepare failed: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($delete_stmt, "i", $product_id);
    
    if (mysqli_stmt_execute($delete_stmt)) {
        $affected_rows = mysqli_stmt_affected_rows($delete_stmt);
        file_put_contents('../debug.log', "Deleted rows: $affected_rows\n", FILE_APPEND);
        
        if ($affected_rows > 0) {
            echo json_encode([
                'success' => true, 
                'message' => 'Product deleted successfully',
                'deleted_id' => $product_id
            ]);
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'No product was deleted'
            ]);
        }
    } else {
        throw new Exception('Delete execute failed: ' . mysqli_stmt_error($delete_stmt));
    }
    
    mysqli_stmt_close($delete_stmt);
    
} catch (Exception $e) {
    file_put_contents('../debug.log', "Exception: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode([
        'success' => false, 
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}

mysqli_close($conn);
exit();
?>