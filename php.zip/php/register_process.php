<?php
// register_process.php
session_start();

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
    $email = mysqli_real_escape_string($conn, $_POST['email'] ?? '');
    $no_telp = mysqli_real_escape_string($conn, $_POST['no_telp'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validasi input
    $errors = [];
    
    if (empty($username)) {
        $errors[] = "Username harus diisi";
    }
    
    if (empty($email)) {
        $errors[] = "Email harus diisi";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format email tidak valid";
    }
    
    if (empty($password)) {
    $errors[] = "Password harus diisi";
    }
    
    if (empty($no_telp)) {
        $errors[] = "No Telepon harus diisi";
    }
    
    // Cek apakah username sudah ada
    if (empty($errors)) {
        $check_username = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($conn, $check_username);
        if ($result && mysqli_num_rows($result) > 0) {
            $errors[] = "Username sudah digunakan";
        }
    }
    
    // Cek apakah email sudah ada
    if (empty($errors)) {
        $check_email = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $check_email);
        if ($result && mysqli_num_rows($result) > 0) {
            $errors[] = "Email sudah terdaftar";
        }
    }
    
    // Jika ada error, redirect kembali
    if (!empty($errors)) {
        $error_message = urlencode(implode(", ", $errors));
        header("Location: ../login/registrasi.html?error=$error_message");
        exit();
    }
    
    // Hash password (bisa hash meskipun hanya 3 karakter)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert user baru ke database
    $sql = "INSERT INTO users (username, email, password, no_telp, level) 
            VALUES ('$username', '$email', '$hashed_password', '$no_telp', 'user')";
    
    if (mysqli_query($conn, $sql)) {
        // Registrasi berhasil
        header("Location: ../login/index.html?success=" . urlencode("Registrasi berhasil! Silakan login"));
        exit();
    } else {
        $error_msg = "Terjadi kesalahan: " . mysqli_error($conn);
        header("Location: ../login/registrasi.html?error=" . urlencode($error_msg));
        exit();
    }
    
    mysqli_close($conn);
} else {
    header("Location: ../login/registrasi.html");
    exit();
}
?>