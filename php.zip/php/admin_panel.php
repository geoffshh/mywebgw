<?php
// admin_panel.php
session_start();

// Cek login dan level admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../login/index.html");
    exit();
}

if ($_SESSION['user_level'] !== 'admin') {
    echo "<h2 style='color: red; text-align: center; margin-top: 50px;'>❌ Akses Ditolak!</h2>";
    echo "<p style='text-align: center;'>Hanya admin yang bisa mengakses halaman ini.</p>";
    echo "<p style='text-align: center;'><a href='../landing/Studiova-1.0.0/index.html'>Kembali ke Home</a></p>";
    exit();
}

require_once 'db.php';

// Handle update level
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_level'])) {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $new_level = mysqli_real_escape_string($conn, $_POST['level']);
    
    // Update level user
    $update_sql = "UPDATE users SET level = '$new_level' WHERE id = '$user_id'";
    if (mysqli_query($conn, $update_sql)) {
        $message = "✅ Level user berhasil diubah!";
    } else {
        $message = "❌ Gagal mengubah level: " . mysqli_error($conn);
    }
}

// Handle delete user
if (isset($_GET['delete'])) {
    $user_id = mysqli_real_escape_string($conn, $_GET['delete']);
    
    // Jangan hapus diri sendiri atau user dengan id 1
    if ($user_id != $_SESSION['user_id'] && $user_id != 1) {
        $delete_sql = "DELETE FROM users WHERE id = '$user_id'";
        if (mysqli_query($conn, $delete_sql)) {
            $message = "✅ User berhasil dihapus!";
        }
    } else {
        $message = "❌ Tidak bisa menghapus admin utama atau akun sendiri!";
    }
}

// Ambil semua user dari database
$users_sql = "SELECT id, username, email, level, created_at FROM users ORDER BY id";
$users_result = mysqli_query($conn, $users_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - User Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .admin-header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 30px;
        }
        
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .admin-header h1 {
            color: #333;
            font-size: 28px;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info p {
            color: #666;
            margin-bottom: 5px;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .badge-admin {
            background: #dc3545;
            color: white;
        }
        
        .badge-user {
            background: #28a745;
            color: white;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn-logout {
            background: #dc3545;
            color: white;
        }
        
        .btn-logout:hover {
            background: #c82333;
        }
        
        .btn-home {
            background: #007bff;
            color: white;
        }
        
        .btn-home:hover {
            background: #0056b3;
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .users-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            padding: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
        }
        
        tr:hover {
            background: #f9f9f9;
        }
        
        .level-select {
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: white;
        }
        
        .btn-update {
            background: #28a745;
            color: white;
            padding: 5px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .btn-update:hover {
            background: #218838;
        }
        
        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 5px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-delete:hover {
            background: #c82333;
        }
        
        .no-users {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .instructions {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .instructions h3 {
            color: #333;
            margin-bottom: 15px;
        }
        
        .instructions ul {
            padding-left: 20px;
            color: #666;
        }
        
        .instructions li {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <div class="header-top">
                <h1>🛠️ Admin Panel - User Management</h1>
                <div class="user-info">
                    <p>Login sebagai: <strong><?php echo $_SESSION['username']; ?></strong></p>
                    <p>Level: <span class="badge badge-admin"><?php echo $_SESSION['user_level']; ?></span></p>
                    <div class="action-buttons">
                        <a href="../landing/Studiova-1.0.0/index.html" class="btn btn-home">🏠 Home</a>
                        <a href="logout.php" class="btn btn-logout">🚪 Logout</a>
                    </div>
                </div>
            </div>
            
            <?php if ($message): ?>
                <div class="message <?php echo strpos($message, '✅') !== false ? 'success' : 'error'; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="users-table">
            <h2 style="margin-bottom: 20px; color: #333;">📋 Daftar User</h2>
            
            <?php if (mysqli_num_rows($users_result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Level</th>
                            <th>Tanggal Daftar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = mysqli_fetch_assoc($users_result)): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td>
                                <?php echo htmlspecialchars($user['username']); ?>
                                <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                    <span class="badge badge-admin">Anda</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <select name="level" class="level-select" 
                                            onchange="if(confirm('Ubah level user <?php echo $user['username']; ?>?')) this.form.submit()">
                                        <option value="user" <?php echo $user['level'] == 'user' ? 'selected' : ''; ?>>User</option>
                                        <option value="admin" <?php echo $user['level'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    </select>
                                    <input type="hidden" name="update_level" value="1">
                                </form>
                            </td>
                            <td><?php echo $user['created_at']; ?></td>
                            <td>
                                <?php if ($user['id'] != $_SESSION['user_id'] && $user['id'] != 1): ?>
                                    <a href="?delete=<?php echo $user['id']; ?>" 
                                       class="btn-delete"
                                       onclick="return confirm('Hapus user <?php echo $user['username']; ?>?')">
                                       ❌ Hapus
                                    </a>
                                <?php else: ?>
                                    <span style="color: #999; font-size: 12px;">Tidak bisa dihapus</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-users">
                    <p>😴 Tidak ada user terdaftar.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="instructions">
            <h3>📝 Cara Menggunakan Admin Panel:</h3>
            <ul>
                <li><strong>Ubah Level:</strong> Pilih level dari dropdown untuk mengubah user menjadi Admin atau User</li>
                <li><strong>Hapus User:</strong> Klik tombol ❌ untuk menghapus user (kecuali admin utama dan akun sendiri)</li>
                <li><strong>Admin:</strong> Bisa akses halaman admin dan mengelola user</li>
                <li><strong>User:</strong> Hanya bisa akses halaman landing page biasa</li>
                <li><strong>Redirect Otomatis:</strong> Setelah login, user akan diarahkan ke halaman sesuai levelnya</li>
            </ul>
        </div>
    </div>
    
    <script>
        // Auto-hide message after 5 seconds
        setTimeout(function() {
            var message = document.querySelector('.message');
            if (message) {
                message.style.transition = 'opacity 0.5s';
                message.style.opacity = '0';
                setTimeout(function() {
                    message.style.display = 'none';
                }, 500);
            }
        }, 5000);
    </script>
</body>
</html>

<?php mysqli_close($conn); ?>