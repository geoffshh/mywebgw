<?php
// update_product.php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Cek login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Harus login terlebih dahulu.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get form data
    $product_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $product_name = isset($_POST['product_name']) ? mysqli_real_escape_string($conn, trim($_POST['product_name'])) : '';
    $description = isset($_POST['description']) ? mysqli_real_escape_string($conn, trim($_POST['description'])) : '';
    $price_raw = isset($_POST['price']) ? $_POST['price'] : '0';
    $category = isset($_POST['category']) ? mysqli_real_escape_string($conn, $_POST['category']) : 'Other';
    $stock = isset($_POST['stock']) ? intval($_POST['stock']) : 0;
    $status = isset($_POST['status']) ? mysqli_real_escape_string($conn, $_POST['status']) : 'draft';
    
    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'ID produk tidak valid.']);
        exit();
    }
    
    // Validasi input (sama seperti upload)
    $price_clean = preg_replace('/[^0-9]/', '', $price_raw);
    
    if (empty($product_name)) {
        echo json_encode(['success' => false, 'message' => 'Nama produk harus diisi']);
        exit();
    }
    
    if (empty($price_clean) || !is_numeric($price_clean)) {
        echo json_encode(['success' => false, 'message' => 'Format harga tidak valid']);
        exit();
    }
    
    $price = floatval($price_clean);
    
    // Cek apakah produk ada dan milik user
    $check_sql = "SELECT created_by FROM products WHERE id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "i", $product_id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    $product = mysqli_fetch_assoc($check_result);
    
    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'Produk tidak ditemukan.']);
        exit();
    }
    
    // Cek hak akses
    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
    $is_admin = isset($_SESSION['user_level']) && $_SESSION['user_level'] === 'admin';
    
    if (!$is_admin && $product['created_by'] != $user_id) {
        echo json_encode(['success' => false, 'message' => 'Tidak memiliki izin untuk mengedit produk ini.']);
        exit();
    }
    
    // Handle image upload jika ada
    $image_url = '';
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        // Sama seperti di product_upload.php
        $file = $_FILES['product_image'];
        $upload_dir = '../assets/uploads/products/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $max_size = 5 * 1024 * 1024;
        
        if (in_array($file['type'], $allowed_types) && $file['size'] <= $max_size) {
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'product_' . uniqid() . '_' . time() . '.' . $ext;
            $filepath = $upload_dir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $image_url = 'assets/uploads/products/' . $filename;
                
                // Hapus gambar lama jika ada
                $old_image_sql = "SELECT image_url FROM products WHERE id = ?";
                $old_stmt = mysqli_prepare($conn, $old_image_sql);
                mysqli_stmt_bind_param($old_stmt, "i", $product_id);
                mysqli_stmt_execute($old_stmt);
                $old_result = mysqli_stmt_get_result($old_stmt);
                $old_product = mysqli_fetch_assoc($old_result);
                
                if (!empty($old_product['image_url'])) {
                    $old_path = '../' . $old_product['image_url'];
                    if (file_exists($old_path)) {
                        unlink($old_path);
                    }
                }
            }
        }
    }
    
    // Update query
    if (!empty($image_url)) {
        $sql = "UPDATE products SET 
                product_name = ?, 
                description = ?, 
                price = ?, 
                category = ?, 
                stock = ?, 
                image_url = ?, 
                status = ?, 
                updated_at = NOW() 
                WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssdissii", 
            $product_name, $description, $price, $category, $stock, $image_url, $status, $product_id);
    } else {
        $sql = "UPDATE products SET 
                product_name = ?, 
                description = ?, 
                price = ?, 
                category = ?, 
                stock = ?, 
                status = ?, 
                updated_at = NOW() 
                WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssdisii", 
            $product_name, $description, $price, $category, $stock, $status, $product_id);
    }
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode([
            'success' => true,
            'message' => 'Produk berhasil diperbarui.',
            'product_id' => $product_id
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Gagal memperbarui produk: ' . mysqli_error($conn)
        ]);
    }
    
    mysqli_stmt_close($stmt);
    
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

mysqli_close($conn);
?>