<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
  echo json_encode([
    'success' => false,
    'message' => 'Unauthorized'
  ]);
  exit;
}

require_once 'db.php';

header('Content-Type: application/json');

// parameter
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$category = isset($_GET['category']) ? mysqli_real_escape_string($conn, $_GET['category']) : '';
$status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// validasi
if ($page < 1) $page = 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// WHERE
$where_conditions = [];
$params = [];
$types = '';

if (!empty($category)) {
    $where_conditions[] = "category = ?";
    $params[] = $category;
    $types .= 's';
}

if (!empty($status)) {
    $where_conditions[] = "status = ?";
    $params[] = $status;
    $types .= 's';
}

if (!empty($search)) {
    $where_conditions[] = "(product_name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= 'ss';
}

$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
}

try {
    // total count
    $count_sql = "SELECT COUNT(*) as total FROM products $where_sql";
    $count_stmt = mysqli_prepare($conn, $count_sql);
    
    if (!empty($params)) {
        mysqli_stmt_bind_param($count_stmt, $types, ...$params);
    }
    
    mysqli_stmt_execute($count_stmt);
    $count_result = mysqli_stmt_get_result($count_stmt);
    $total_row = mysqli_fetch_assoc($count_result);
    $total = $total_row['total'];
    mysqli_stmt_close($count_stmt);
    
    // ambil produk pake pagination
    $sql = "SELECT 
                id,
                product_name,
                description,
                price,
                category,
                stock,
                COALESCE(sold, 0) as sold,
                COALESCE(revenue, 0) as revenue,
                image_url,
                status,
                created_at,
                created_by
            FROM products 
            $where_sql
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    
    if (!$stmt) {
        throw new Exception('Prepare failed: ' . mysqli_error($conn));
    }
    
    if (!empty($params)) {
        $all_params = array_merge($params, [$limit, $offset]);
        $all_types = $types . 'ii';
        mysqli_stmt_bind_param($stmt, $all_types, ...$all_params);
    } else {
        mysqli_stmt_bind_param($stmt, 'ii', $limit, $offset);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $products = [];
    while ($row = mysqli_fetch_assoc($result)) {
        // Format harga
        $row['price_formatted'] = 'Rp ' . number_format($row['price'], 0, ',', '.');
        
        // Format revenue
        $row['revenue_formatted'] = 'Rp ' . number_format($row['revenue'], 0, ',', '.');
        
        // biar gambarnya oke, cek url image
        if (!empty($row['image_url']) && !str_starts_with($row['image_url'], 'http')) {
            if (!str_starts_with($row['image_url'], 'assets/')) {
                $row['image_url'] = 'assets/uploads/products/' . basename($row['image_url']);
            }
        }
        
        $products[] = $row;
    }
    
    mysqli_stmt_close($stmt);
    
    // kirim respons
    echo json_encode([
        'success' => true,
        'products' => $products,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'products' => []
    ]);
}

mysqli_close($conn);
?>