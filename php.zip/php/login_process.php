<?php
// login_process.php - versi tanpa remember_token
session_start();
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    // Validasi
    if (empty($username) || empty($password)) {
        header("Location: ../login/index.html?error=" . urlencode("Username dan password harus diisi"));
        exit();
    }
    
    // Query user
    $sql = "SELECT id, username, password, level FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            // Login berhasil
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_level'] = $user['level'];
            $_SESSION['logged_in'] = true;
            
            // Remember me cookie (simplified - tanpa kolom database)
            if ($remember) {
                // Simpan di cookie saja, tanpa kolom database
                $token_data = [
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'expire' => time() + (86400 * 30)
                ];
                setcookie('remember_me', json_encode($token_data), time() + (86400 * 30), "/");
            }
            
            // REDIRECT BERDASARKAN LEVEL
            if ($_SESSION['user_level'] == 'admin') {
                header("Location: ../admin/index.php");
                exit();
            } else {
                header("Location: ../landing/Studiova-1.0.0/index.html");
                exit();
            }
            
        } else {
            header("Location: ../login/index.html?error=" . urlencode("Password salah"));
            exit();
        }
    } else {
        header("Location: ../login/index.html?error=" . urlencode("Username tidak ditemukan"));
        exit();
    }
    
    mysqli_close($conn);
} else {
    header("Location: ../login/index.html");
    exit();
}
?>