<?php
// update_level.php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $new_level = mysqli_real_escape_string($conn, $_POST['level']);
    
    // Update level
    $update_sql = "UPDATE users SET level = '$new_level' WHERE id = '$user_id'";
    
    if (mysqli_query($conn, $update_sql)) {
        echo "<h2 style='color: green;'>✅ Level berhasil diupdate!</h2>";
        echo "User ID $user_id sekarang level: <strong>$new_level</strong><br><br>";
    } else {
        echo "<h2 style='color: red;'>❌ Error: " . mysqli_error($conn) . "</h2>";
    }
    
    echo "<a href='check_users.php'>← Kembali ke Daftar User</a>";
} else {
    echo "Invalid request";
}

mysqli_close($conn);
?>