<?php

$host = "localhost";
$username = "root";  
$password = "";     
$database = "idk"; 

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}


mysqli_set_charset($conn, "utf8mb4");


date_default_timezone_set('Asia/Jakarta');
?>