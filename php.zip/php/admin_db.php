<?php
// admin_db.php - Database untuk admin content
require_once '../php/db.php';

// Buat tabel untuk konten yang bisa di-custom
$content_table = "CREATE TABLE IF NOT EXISTS admin_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page VARCHAR(100) NOT NULL,
    section VARCHAR(100) NOT NULL,
    content_type ENUM('text', 'html', 'image', 'file') DEFAULT 'text',
    content TEXT,
    media_url VARCHAR(500),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_section (page, section)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $content_table)) {
    echo "Error creating content table: " . mysqli_error($conn);
}

// Buat tabel untuk uploads
$uploads_table = "CREATE TABLE IF NOT EXISTS admin_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255),
    filepath VARCHAR(500) NOT NULL,
    filetype VARCHAR(50),
    filesize INT,
    category VARCHAR(100) DEFAULT 'general',
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $uploads_table)) {
    echo "Error creating uploads table: " . mysqli_error($conn);
}

// Buat tabel untuk settings
$settings_table = "CREATE TABLE IF NOT EXISTS admin_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('text', 'number', 'boolean', 'json') DEFAULT 'text',
    category VARCHAR(100) DEFAULT 'general',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $settings_table);

echo "✅ Admin database tables created/verified";
?>