<?php
// product_upload.php - FIX PUBLISH STATUS
session_start();
require_once 'db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Login required']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name'] ?? '');
    $description = mysqli_real_escape_string($conn, $_POST['description'] ?? '');
    $price_raw = $_POST['price'] ?? '0';
    $category = mysqli_real_escape_string($conn, $_POST['category'] ?? 'Other');
    $stock = intval($_POST['stock'] ?? 0);
    $action = $_POST['action'] ?? 'save';
    
    // Clean price
    $price = floatval(str_replace('.', '', $price_raw));
    
    // Validate
    if (empty($product_name)) {
        echo json_encode(['success' => false, 'message' => 'Nama produk harus diisi']);
        exit();
    }
    
    if ($price <= 0) {
        echo json_encode(['success' => false, 'message' => 'Harga harus lebih dari 0']);
        exit();
    }
    
    // 🎯 FIX INI: Tentukan status berdasarkan action
    $status = 'draft'; // default
    
    if ($action === 'save_publish') {
        $status = 'active'; // ✅ INI YANG PERLU DIPERBAIKI
    } elseif ($action === 'save') {
        $status = 'draft';
    }
    
    // Debug log
    error_log("Action: $action, Status: $status");
    
    $image_url = '';
    
    // Handle image upload
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['product_image'];
        $upload_dir = '../assets/uploads/products/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $max_size = 5 * 1024 * 1024;
        
        if (in_array($file['type'], $allowed_types) && $file['size'] <= $max_size) {
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'product_' . uniqid() . '_' . time() . '.' . $ext;
            $filepath = $upload_dir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $image_url = 'assets/uploads/products/' . $filename;
            }
        }
    }
    
    // Get user ID
    $user_id = $_SESSION['user_id'] ?? 0;
    
    // Insert to database
    $sql = "INSERT INTO products (product_name, description, price, category, stock, image_url, status, created_by) 
            VALUES ('$product_name', '$description', $price, '$category', $stock, '$image_url', '$status', $user_id)";
    
    if (mysqli_query($conn, $sql)) {
        $product_id = mysqli_insert_id($conn);
        
        echo json_encode([
            'success' => true,
            'message' => 'Produk berhasil ' . ($status === 'active' ? 'dipublikasikan' : 'disimpan sebagai draft'),
            'status' => $status,
            'product_id' => $product_id
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . mysqli_error($conn)
        ]);
    }
    
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid method']);
}

mysqli_close($conn);
?>