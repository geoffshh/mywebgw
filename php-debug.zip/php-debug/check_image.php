<?php
// check_image.php
session_start();
require_once 'db.php';

$result = mysqli_query($conn, "SELECT id, product_name, image_url FROM products LIMIT 10");
echo "<h2>Image URLs in Database:</h2>";
while ($row = mysqli_fetch_assoc($result)) {
    $path = '../' . $row['image_url'];
    $exists = file_exists($path) ? '✅' : '❌';
    echo "<p>{$exists} ID {$row['id']}: {$row['product_name']}<br>";
    echo "DB: {$row['image_url']}<br>";
    echo "Path: {$path}<br>";
    echo "Exists: " . ($exists === '✅' ? 'YES' : 'NO') . "</p><hr>";
}
?>