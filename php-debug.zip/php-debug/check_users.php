<?php
// check_users.php
require_once 'db.php';

echo "<h2>Struktur Tabel Users</h2>";

// Cek struktur kolom
$sql = "DESCRIBE users";
$result = mysqli_query($conn, $sql);

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['Field'] . "</td>";
    echo "<td>" . $row['Type'] . "</td>";
    echo "<td>" . $row['Null'] . "</td>";
    echo "<td>" . $row['Key'] . "</td>";
    echo "<td>" . $row['Default'] . "</td>";
    echo "<td>" . $row['Extra'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Tampilkan data user dengan kolom yang ADA (bukan created_at)
echo "<h2>Data Users dengan Level</h2>";

// Cek kolom apa saja yang ada
$columns_sql = "SHOW COLUMNS FROM users";
$columns_result = mysqli_query($conn, $columns_sql);
$column_names = [];
while ($col = mysqli_fetch_assoc($columns_result)) {
    $column_names[] = $col['Field'];
}

// Buat query berdasarkan kolom yang ada
if (in_array('timestamp', $column_names)) {
    // Gunakan timestamp jika ada
    $data_sql = "SELECT id, username, email, password, no_telp, level, timestamp FROM users";
} else {
    // Default ke semua kolom kecuali password
    $data_sql = "SELECT id, username, email, no_telp, level FROM users";
}

$data_result = mysqli_query($conn, $data_sql);

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>No Telp</th><th>Level</th>";

if (in_array('timestamp', $column_names)) {
    echo "<th>Timestamp</th>";
}

echo "</tr>";

if (mysqli_num_rows($data_result) > 0) {
    while ($row = mysqli_fetch_assoc($data_result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . ($row['email'] ?? '-') . "</td>";
        echo "<td>" . ($row['no_telp'] ?? '-') . "</td>";
        echo "<td><strong>" . ($row['level'] ?? 'user') . "</strong></td>";
        
        if (in_array('timestamp', $column_names)) {
            echo "<td>" . ($row['timestamp'] ?? '-') . "</td>";
        }
        
        echo "</tr>";
    }
} else {
    $colspan = in_array('timestamp', $column_names) ? 6 : 5;
    echo "<tr><td colspan='$colspan'>Tidak ada user</td></tr>";
}
echo "</table>";

// Tambahkan form untuk update level
echo "<h2>Update Level User</h2>";
echo "<form method='POST' action='update_level.php'>";
echo "User ID: <input type='number' name='user_id' required><br><br>";
echo "Level: <select name='level'>";
echo "<option value='user'>User</option>";
echo "<option value='admin'>Admin</option>";
echo "</select><br><br>";
echo "<input type='submit' value='Update Level'>";
echo "</form>";

mysqli_close($conn);
?>