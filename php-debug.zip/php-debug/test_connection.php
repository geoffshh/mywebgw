<?php
// test_connection.php - Untuk debugging
session_start();
require_once 'db.php';

echo "<h2>🔍 Debug System Check</h2>";

// 1. Check Database
echo "<h3>1. Database Connection:</h3>";
echo "Server: $db_server<br>";
echo "User: $db_user<br>";
echo "Database: $db_name<br>";

if ($conn) {
    echo "✅ Database connected successfully<br>";
    
    // Check tables
    $tables = ['users', 'products'];
    foreach ($tables as $table) {
        $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
        if (mysqli_num_rows($result) > 0) {
            echo "✅ Table '$table' exists<br>";
            
            // Count rows
            $count = mysqli_query($conn, "SELECT COUNT(*) as total FROM $table");
            $row = mysqli_fetch_assoc($count);
            echo "&nbsp;&nbsp;📊 Records: " . $row['total'] . "<br>";
            
            // Show sample data
            if ($table == 'products' && $row['total'] > 0) {
                $sample = mysqli_query($conn, "SELECT * FROM $table LIMIT 3");
                echo "&nbsp;&nbsp;📋 Sample:<br>";
                while ($data = mysqli_fetch_assoc($sample)) {
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;- {$data['product_name']} (Rp " . number_format($data['price'], 0, ',', '.') . ")<br>";
                }
            }
        } else {
            echo "❌ Table '$table' NOT FOUND<br>";
        }
    }
} else {
    echo "❌ Database connection failed<br>";
}

// 2. Check Session
echo "<h3>2. Session Data:</h3>";
if (isset($_SESSION['username'])) {
    echo "✅ User logged in: " . $_SESSION['username'] . "<br>";
    echo "Level: " . ($_SESSION['level'] ?? 'user') . "<br>";
    echo "User ID: " . ($_SESSION['user_id'] ?? 'not set') . "<br>";
} else {
    echo "❌ No active session<br>";
}

// 3. Test get_products.php
echo "<h3>3. Test get_products.php:</h3>";
$test_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/get_products.php";
echo "URL: <a href='$test_url' target='_blank'>$test_url</a><br>";

// 4. Folder permissions
echo "<h3>4. Folder Permissions:</h3>";
$folders = ['../assets/uploads/products/', 'php/'];
foreach ($folders as $folder) {
    if (is_writable($folder)) {
        echo "✅ $folder is writable<br>";
    } else {
        echo "❌ $folder is NOT writable<br>";
    }
}

// 5. Test query langsung
echo "<h3>5. Direct Query Test:</h3>";
$test_query = "SELECT p.*, u.username FROM products p LEFT JOIN users u ON p.created_by = u.id LIMIT 5";
$result = mysqli_query($conn, $test_query);

if ($result) {
    $count = mysqli_num_rows($result);
    echo "✅ Query executed successfully ($count rows)<br>";
    
    if ($count > 0) {
        echo "<table border='1'><tr><th>ID</th><th>Product</th><th>Price</th><th>Created By</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$row['id']}</td>";
            echo "<td>{$row['product_name']}</td>";
            echo "<td>Rp " . number_format($row['price'], 0, ',', '.') . "</td>";
            echo "<td>{$row['username']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "📭 No products found in database<br>";
        
        // Try to create sample product
        echo "<br><button onclick=\"createSample()\">➕ Create Sample Product</button>";
        echo "<script>
        function createSample() {
            fetch('php/product_upload.php', {
                method: 'POST',
                body: new URLSearchParams({
                    product_name: 'Sample Product',
                    description: 'This is a test product',
                    price: '1000000',
                    category: 'Other',
                    stock: '10',
                    action: 'save_publish'
                })
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                location.reload();
            });
        }
        </script>";
    }
} else {
    echo "❌ Query failed: " . mysqli_error($conn) . "<br>";
}

mysqli_close($conn);
?>