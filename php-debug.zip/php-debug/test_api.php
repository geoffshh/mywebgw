<?php
// test_api.php - Taruh di folder yang sama dengan forms-elements.html
echo "<h2>🔧 API Endpoint Test</h2>";

$endpoints = [
    'get_products.php' => '/idk/php/get_products.php',
    'product_upload.php' => '/idk/php/product_upload.php',
    'Current directory' => __DIR__,
    'Current file' => __FILE__
];

foreach ($endpoints as $name => $path) {
    echo "<h4>Testing: $name</h4>";
    
    if (file_exists(str_replace('/idk/', '', $path))) {
        echo "✅ File exists physically<br>";
        
        // Test URL access
        $url = "http://localhost" . $path;
        $context = stream_context_create(['http' => ['ignore_errors' => true]]);
        $response = @file_get_contents($url, false, $context);
        
        if ($response !== false) {
            echo "✅ Accessible via HTTP<br>";
            echo "<pre>" . htmlspecialchars(substr($response, 0, 500)) . "...</pre>";
        } else {
            echo "❌ Not accessible via HTTP<br>";
        }
    } else {
        echo "❌ File not found<br>";
        echo "Expected path: " . realpath(str_replace('/idk/', '', $path)) . "<br>";
    }
    echo "<hr>";
}

// Test langsung get_products.php
echo "<h3>Direct Test get_products.php:</h3>";
include_once 'php/db.php';
include_once 'php/get_products.php';
?>