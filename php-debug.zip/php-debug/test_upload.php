<?php
// test_upload.php - Test upload functionality
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_level'] = 'admin';
$_SESSION['user_id'] = 1;

require_once 'db.php';

echo "<h2>Test Upload Functionality</h2>";

// Test 1: Cek koneksi
echo "<h3>1. Database Connection:</h3>";
if ($conn) {
    echo "✅ Connected to database<br>";
    
    // Test 2: Cek tabel products
    $check_table = "SHOW TABLES LIKE 'products'";
    $result = mysqli_query($conn, $check_table);
    if (mysqli_num_rows($result) > 0) {
        echo "✅ Products table exists<br>";
    } else {
        echo "❌ Products table doesn't exist<br>";
    }
    
    // Test 3: Cek session
    echo "<h3>2. Session Status:</h3>";
    echo "Logged in: " . ($_SESSION['logged_in'] ? 'Yes' : 'No') . "<br>";
    echo "User level: " . ($_SESSION['user_level'] ?? 'None') . "<br>";
    
    // Test 4: Simple form untuk test
    echo "<h3>3. Test Form:</h3>";
    echo <<<HTML
    <form method="POST" enctype="multipart/form-data" action="product_upload.php">
        <input type="hidden" name="form_action" value="save">
        
        <div class="mb-3">
            <label>Product Name:</label>
            <input type="text" name="product_name" class="form-control" value="Test Product" required>
        </div>
        
        <div class="mb-3">
            <label>Price:</label>
            <input type="number" name="price" class="form-control" value="99.99" step="0.01" required>
        </div>
        
        <div class="mb-3">
            <label>Category:</label>
            <select name="category" class="form-control">
                <option>Electronics</option>
                <option>Fashion</option>
            </select>
        </div>
        
        <button type="submit" class="btn btn-primary">Test Submit</button>
    </form>
HTML;

} else {
    echo "❌ Database connection failed";
}

mysqli_close($conn);
?>