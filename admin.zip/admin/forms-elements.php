<?php
session_start();
require_once 'db.php';
require_once 'auth.php';

requireLogin();
$user = currentUser($conn); 

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Forms / Elements - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><h2><?= htmlspecialchars($user['username']) ?></h2></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h2><?= htmlspecialchars($user['username']) ?></h2>
              <span>Web Designer</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

    <!-- Dashboard -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="index.php">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li>

    <!-- USERS -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="tables-data-user.php">
        <i class="bi bi-people"></i>
        <span>Users</span>
      </a>
    </li>

    <!-- PRODUCTS -->
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#products-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-box"></i>
        <span>Products</span>
        <i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="products-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
        <li>
          <a href="tables-data.php">
            <i class="bi bi-circle"></i><span>Data Barang</span>
          </a>
        </li>
        <li>
          <a href="forms-elements.php">
            <i class="bi bi-circle"></i><span>Upload Produk</span>
          </a>
        </li>
      </ul>
    </li>

    <!-- LOGOUT -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Logout</span>
      </a>
    </li>

  </ul>

</aside>
<!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Upload Barang</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Upload Barang</li>
        </ol>
      </nav>
    </div><!-- End Page Title --

    <section class="section">
      <div class="row">
        <div class="col-lg-6">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">General Form Elements</h5>

              <!-- General Form Elements --
              <form>
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Text</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                  <div class="col-sm-10">
                    <input type="email" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">Number</label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">File Upload</label>
                  <div class="col-sm-10">
                    <input class="form-control" type="file" id="formFile">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputDate" class="col-sm-2 col-form-label">Date</label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputTime" class="col-sm-2 col-form-label">Time</label>
                  <div class="col-sm-10">
                    <input type="time" class="form-control">
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputColor" class="col-sm-2 col-form-label">Color Picker</label>
                  <div class="col-sm-10">
                    <input type="color" class="form-control form-control-color" id="exampleColorInput" value="#4154f1" title="Choose your color">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword" class="col-sm-2 col-form-label">Textarea</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" style="height: 100px"></textarea>
                  </div>
                </div>
                <fieldset class="row mb-3">
                  <legend class="col-form-label col-sm-2 pt-0">Radios</legend>
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
                      <label class="form-check-label" for="gridRadios1">
                        First radio
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
                      <label class="form-check-label" for="gridRadios2">
                        Second radio
                      </label>
                    </div>
                    <div class="form-check disabled">
                      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios" value="option" disabled>
                      <label class="form-check-label" for="gridRadios3">
                        Third disabled radio
                      </label>
                    </div>
                  </div>
                </fieldset>
                <div class="row mb-3">
                  <legend class="col-form-label col-sm-2 pt-0">Checkboxes</legend>
                  <div class="col-sm-10">

                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" id="gridCheck1">
                      <label class="form-check-label" for="gridCheck1">
                        Example checkbox
                      </label>
                    </div>

                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" id="gridCheck2" checked>
                      <label class="form-check-label" for="gridCheck2">
                        Example checkbox 2
                      </label>
                    </div>

                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Disabled</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="Read only / Disabled" disabled>
                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Select</label>
                  <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example">
                      <option selected>Open this select menu</option>
                      <option value="1">One</option>
                      <option value="2">Two</option>
                      <option value="3">Three</option>
                    </select>
                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Multi Select</label>
                  <div class="col-sm-10">
                    <select class="form-select" multiple aria-label="multiple select example">
                      <option selected>Open this select menu</option>
                      <option value="1">One</option>
                      <option value="2">Two</option>
                      <option value="3">Three</option>
                    </select>
                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Submit Button</label>
                  <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Submit Form</button>
                  </div>
                </div>

              </form><!-- End General Form Elements --

            </div>
          </div>

        </div>

        <div class="col-lg-6">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Advanced Form Elements</h5>

              <!-- Advanced Form Elements --
              <form>
                <div class="row mb-5">
                  <label class="col-sm-2 col-form-label">Switches</label>
                  <div class="col-sm-10">
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                      <label class="form-check-label" for="flexSwitchCheckDefault">Default switch checkbox input</label>
                    </div>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" checked>
                      <label class="form-check-label" for="flexSwitchCheckChecked">Checked switch checkbox input</label>
                    </div>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckDisabled" disabled>
                      <label class="form-check-label" for="flexSwitchCheckDisabled">Disabled switch checkbox input</label>
                    </div>
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckCheckedDisabled" checked disabled>
                      <label class="form-check-label" for="flexSwitchCheckCheckedDisabled">Disabled checked switch checkbox input</label>
                    </div>
                  </div>
                </div>

                <div class="row mb-5">
                  <label class="col-sm-2 col-form-label">Ranges</label>
                  <div class="col-sm-10">
                    <div>
                      <label for="customRange1" class="form-label">Example range</label>
                      <input type="range" class="form-range" id="customRange1">
                    </div>
                    <div>
                      <label for="disabledRange" class="form-label">Disabled range</label>
                      <input type="range" class="form-range" id="disabledRange" disabled>
                    </div>
                    <div>
                      <label for="customRange2" class="form-label">Min and max with steps</label>
                      <input type="range" class="form-range" min="0" max="5" step="0.5" id="customRange2">
                    </div>
                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Floating labels</label>
                  <div class="col-sm-10">
                    <div class="form-floating mb-3">
                      <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                      <label for="floatingInput">Email address</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                      <label for="floatingPassword">Password</label>
                    </div>
                    <div class="form-floating mb-3">
                      <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" style="height: 100px;"></textarea>
                      <label for="floatingTextarea">Comments</label>
                    </div>
                    <div class="form-floating mb-3">
                      <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                        <option selected>Open this select menu</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                      </select>
                      <label for="floatingSelect">Works with selects</label>
                    </div>
                  </div>
                </div>

                <div class="row mb-5">
                  <label class="col-sm-2 col-form-label">Input groups</label>
                  <div class="col-sm-10">
                    <div class="input-group mb-3">
                      <span class="input-group-text" id="basic-addon1">@</span>
                      <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1">
                    </div>

                    <div class="input-group mb-3">
                      <input type="text" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2">
                      <span class="input-group-text" id="basic-addon2">@example.com</span>
                    </div>

                    <label for="basic-url" class="form-label">Your vanity URL</label>
                    <div class="input-group mb-3">
                      <span class="input-group-text" id="basic-addon3">https://example.com/users/</span>
                      <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3">
                    </div>

                    <div class="input-group mb-3">
                      <span class="input-group-text">$</span>
                      <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
                      <span class="input-group-text">.00</span>
                    </div>

                    <div class="input-group mb-3">
                      <input type="text" class="form-control" placeholder="Username" aria-label="Username">
                      <span class="input-group-text">@</span>
                      <input type="text" class="form-control" placeholder="Server" aria-label="Server">
                    </div>

                    <div class="input-group">
                      <span class="input-group-text">With textarea</span>
                      <textarea class="form-control" aria-label="With textarea"></textarea>
                    </div>
                  </div>
                </div>

              </form><!-- End General Form Elements -->
              <!-- ======= Product Upload Section ======= -->
<section class="section">
  <div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Unggah Produk Baru</h5>
          
          <!-- Form untuk upload produk -->
          <form id="productForm" action="../php/product_upload.php" method="POST" enctype="multipart/form-data">
            
            <!-- Row 1: Product Name & Price -->
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="productName" class="form-label">Nama Produk </label>
                <input type="text" class="form-control" id="productName" name="product_name" required placeholder="e.g., Ut inventore ipsa voluptas nulla">
              </div>
              <div class="col-md-6">
                <label for="price" class="form-label">Harga</label>
                <div class="input-group">
                  <span class="input-group-text">Rp</span>
                  <input 
                    type="text" 
                    class="form-control" 
                    id="price" 
                    name="price" 
                    inputmode="numeric"
                    placeholder="1.000.000"
                    required
                  >

                </div>
              </div>
            </div>

            <!-- Row 2: Category & Stock -->
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="category" class="form-label">Kategori</label>
                <select class="form-select" id="category" name="category">
                  <option value="Electronics">Elektronik</option>
                  <option value="Fashion">Fashion</option>
                  <option value="Home">Musik</option>
                  <option value="Books">Buku</option>
                  <option value="Sports">Olahraga</option>
                  <option value="Other">Lainnya</option>
                </select>
              </div>
              <div class="col-md-6">
                <label for="stock" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stock" name="stock" min="0" value="0">
              </div>
            </div>

            <!-- Row 3: Product Image -->
            <div class="row mb-3">
              <div class="col-md-12">
                <label for="productImage" class="form-label">Gambar Produk</label>
                <div class="upload-area" id="dropArea" 
                     style="border: 2px dashed #ddd; padding: 20px; text-align: center; border-radius: 8px; cursor: pointer; background: #f8f9fa;">
                  <i class="bi bi-image" style="font-size: 48px; color: #6c757d;"></i>
                  <h6 class="mt-2">Drag & Drop Gambar Produk</h6>
                  <p class="text-muted mb-2">atau pilih sendiri</p>
                  <input type="file" name="product_image" id="productImage" class="d-none" accept="image/*">
                  <button type="button" class="btn btn-sm btn-outline-primary" onclick="document.getElementById('productImage').click()">
                    <i class="bi bi-folder2-open"></i> Pilih File
                  </button>
                </div>
                
                <!-- Image Preview -->
                <div id="imagePreviewContainer" class="mt-3 text-center" style="display: none;">
                  <img id="imagePreview" class="img-thumbnail" style="max-height: 150px;">
                  <div class="mt-2">
                    <button type="button" class="btn btn-sm btn-danger" onclick="removePreview()">
                      <i class="bi bi-trash"></i> Hapus Gambar
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Row 4: Description -->
            <div class="row mb-3">
              <div class="col-md-12">
                <label for="description" class="form-label">Deskirpsi Produk</label>
                <textarea class="form-control" id="description" name="description" rows="3" 
                          placeholder="Describe your product..."></textarea>
              </div>
            </div>

            <!-- Submit Buttons -->
            <!-- Ganti bagian tombol submit -->
            <div class="text-center">
                <button type="submit" name="action" value="save" class="btn btn-primary">
                <i class="bi bi-check-circle me-2"></i>Simpan Draft
                </button>
                <button type="submit" name="action" value="save_publish" class="btn btn-success">
                <i class="bi bi-upload me-2"></i>Simpan & Publikasikan
                </button>
                <button type="reset" class="btn btn-secondary">
                <i class="bi bi-x-circle me-2"></i>Reset Form
                </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End Product Upload Section -->

<!-- ======= Product List Section ======= -->
<section class="section">
  <div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">List Produk<span> | Hari ini</span></h5>
          
          <!-- Product Filter -->
          <div class="row mb-3">
            <div class="col-md-3">
              <select class="form-select" id="filterCategory" onchange="filterProducts()">
                <option value="">Semua Kategori</option>
                <option value="Electronics">Elektronik</option>
                <option value="Fashion">Fashion</option>
                <option value="Home">Musik</option>
                <option value="Books">Buku</option>
                <option value="Sports">Olahraga</option>
                <option value="Sports">Lainnya</option>
              </select>
            </div>
            <div class="col-md-3">
              <select class="form-select" id="filterStatus" onchange="filterProducts()">
                <option value="">All Status</option>
                <option value="active">Aktif</option>
                <option value="inactive">Tidak Aktif</option>
                <option value="draft">Draft</option>
              </select>
            </div>
            <div class="col-md-6">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search products..." id="searchProduct">
                <button class="btn btn-outline-primary" type="button" onclick="searchProducts()">
                  <i class="bi bi-search"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Products Table -->
          <div class="table-responsive">
            <table class="table table-hover" id="productsMainTable">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Preview</th>
                  <th scope="col">Produk</th>
                  <th scope="col">Harga</th>
                  <th scope="col">Stok</th>
                  <th scope="col">Banyak Unit Terjual</th>
                  <th scope="col">Pendapatan Kotor</th>
                  <th scope="col">Status</th>
                  <th scope="col">Aksi</th>
                </tr>
              </thead>
              <tbody id="productTableBody">
                <!-- Data akan di-load via AJAX -->
                <tr>
                  <td colspan="9" class="text-center">
                    <div class="spinner-border text-primary" role="status">
                      <span class="visually-hidden">Loading...</span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center" id="pagination">
              <!-- Pagination akan di-generate via JavaScript -->
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End Product List Section -->

<style>
.highlight {
    border-color: #0d6efd !important;
    background: #e7f1ff !important;
}

#dropArea {
    transition: all 0.3s ease;
    cursor: pointer;
}

#dropArea:hover {
    border-color: #0d6efd;
    background: #f8f9fa;
}
</style>

<!-- ======= JavaScript Section ======= -->
<script>
// ==================== STOP SIMPLE-DATATABLES ====================
(function() {
    // Hentikan simple-datatables SEBELUM dia jalan
    const originalInit = window.simpleDatatablesInit;
    window.simpleDatatablesInit = function() {
        console.log('⏸️ Blocking simple-datatables initialization...');
        // Skip semua tabel yang berhubungan dengan produk
        document.querySelectorAll('table').forEach(table => {
            if (table.id && table.id.includes('product') || 
                table.querySelector('#productTableBody') ||
                table.closest('[id*="product"]')) {
                table.classList.remove('datatable');
                console.log('✅ Blocked datatable for product table');
            }
        });
        
        // Jalankan original hanya untuk tabel lain
        if (originalInit) {
            return originalInit.apply(this, arguments);
        }
    };
})();

// ==================== KONFIGURASI ====================
const API_BASE = '../php/';
const UPLOADS_BASE = '../assets/uploads/products/';

// ==================== GLOBAL FUNCTIONS ====================
window.editProduct = function(id) {
    if (!confirm('Edit produk ID ' + id + '?')) return;
    
    fetch(API_BASE + 'get_product.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${id}`
    })
    .then(response => {
        if (!response.ok) throw new Error('HTTP ' + response.status);
        return response.json();
    })
    .then(data => {
        if (data.success) {
            const product = data.product;
            
            // Isi form
            document.getElementById('productName').value = product.product_name;
            document.getElementById('description').value = product.description;
            document.getElementById('price').value = product.price_formatted ? product.price_formatted.replace('Rp ', '') : product.price;
            document.getElementById('category').value = product.category;
            document.getElementById('stock').value = product.stock;
            
            // Tampilkan gambar jika ada
            if (product.image_url) {
                const previewContainer = document.getElementById('imagePreviewContainer');
                const imagePreview = document.getElementById('imagePreview');
                if (previewContainer && imagePreview) {
                    imagePreview.src = '../' + product.image_url;
                    previewContainer.style.display = 'block';
                }
            }
            
            // Scroll ke form
            document.querySelector('#productForm').scrollIntoView({behavior: 'smooth'});
            window.showAlert('info', `Edit mode: ${product.product_name}`);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Gagal memuat data produk');
    });
};

window.deleteProduct = function(id) {
    if (!confirm('Yakin ingin menghapus produk ID ' + id + '?')) return;
    
    console.log('🗑️ Deleting product ID:', id);
    
    fetch(API_BASE + 'delete_product.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${id}`
    })
    .then(response => response.text())
    .then(text => {
        console.log('Delete response:', text);
        try {
            const data = JSON.parse(text);
            if (data.success) {
                showAlert('success', data.message || 'Produk berhasil dihapus');
                loadProducts();
            } else {
                showAlert('danger', data.message || 'Gagal menghapus produk');
                loadProducts();
            }
        } catch(e) {
            console.error('JSON parse error:', e, 'Response:', text);
            showAlert('danger', 'Server error: ' + text.substring(0, 100));
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        showAlert('danger', 'Network error: ' + error.message);
    });
};

window.showAlert = function(type, message) {
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show mt-3`;
    alertDiv.innerHTML = `
        <i class="bi ${type === 'success' ? 'bi-check-circle' : 'bi-exclamation-triangle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const cardBody = document.querySelector('.card-body');
    if (cardBody) cardBody.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentElement) alertDiv.remove();
    }, 5000);
};

window.toggleProductStatus = function(productId, isChecked) {
    const newStatus = isChecked ? 'active' : 'inactive';
    console.log('🔄 Toggle status for product', productId, 'to', newStatus);

    if (!confirm(`Ubah status produk menjadi ${newStatus === 'active' ? 'AKTIF' : 'NONAKTIF'}?`)) {
        // Reload to reset
        loadProducts();
        return;
    }

    fetch(API_BASE + 'update_product_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `product_id=${productId}&status=${newStatus}`
    })
    .then(res => {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
    })
    .then(data => {
        console.log('Status update response:', data);
        if (data.success) {
            showAlert('success', data.message || 'Status berhasil diubah');
            // Reload setelah 500ms
            setTimeout(() => loadProducts(), 500);
        } else {
            showAlert('danger', data.message || 'Gagal mengubah status');
            loadProducts(); // Reload untuk reset
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showAlert('danger', 'Gagal koneksi ke server');
        loadProducts(); // Reload untuk reset
    });
};

// ==================== DOM READY ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Product system initializing...');
    
    // Setup drag & drop
    setupDragDrop();
    
    // Setup event listeners
    setupEventListeners();
    
    // Hapus class datatable dari semua tabel produk
    setTimeout(() => {
        document.querySelectorAll('table').forEach(table => {
            if (table.id && (table.id.includes('product') || table.id.includes('Product'))) {
                table.classList.remove('datatable');
                console.log('✅ Removed datatable class from:', table.id);
            }
        });
    }, 100);
    
    // Load products pertama kali
    setTimeout(() => {
        console.log('📦 Loading initial products...');
        loadProducts();
    }, 500);
    
    // Tambahkan debug button
    addDebugButton();
});

// ==================== DRAG & DROP ====================
function setupDragDrop() {
    const dropArea = document.getElementById('dropArea');
    const fileInput = document.getElementById('productImage');
    const previewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');

    if (!dropArea || !fileInput) return;

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    // Highlight drop area
    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight(e) {
        dropArea.classList.add('highlight');
        dropArea.style.borderColor = '#0d6efd';
        dropArea.style.background = '#e7f1ff';
    }
    
    function unhighlight(e) {
        dropArea.classList.remove('highlight');
        dropArea.style.borderColor = '#ddd';
        dropArea.style.background = '#f8f9fa';
    }
    
    // Handle drop
    dropArea.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length) {
            fileInput.files = files;
            showPreview(files[0]);
        }
    }
    
    // Click to select file
    dropArea.addEventListener('click', () => {
        fileInput.click();
    });
    
    // File input change
    fileInput.addEventListener('change', function(e) {
        if (e.target.files.length) {
            showPreview(e.target.files[0]);
        }
    });
    
    function showPreview(file) {
        if (!file.type.match('image.*')) {
            alert('Hanya file gambar yang diperbolehkan!');
            return;
        }
        
        const reader = new FileReader();
        
        reader.onload = function(e) {
            if (imagePreview) {
                imagePreview.src = e.target.result;
            }
            if (previewContainer) {
                previewContainer.style.display = 'block';
            }
            
            // Update drop area text
            if (dropArea) {
                const h6 = dropArea.querySelector('h6');
                const p = dropArea.querySelector('p');
                if (h6) h6.textContent = file.name;
                if (p) p.textContent = 'Klik untuk ganti gambar';
            }
        };
        
        reader.readAsDataURL(file);
    }
    
    window.removePreview = function() {
        if (fileInput) fileInput.value = '';
        if (previewContainer) previewContainer.style.display = 'none';
        if (imagePreview) imagePreview.src = '';
        if (dropArea) {
            const h6 = dropArea.querySelector('h6');
            const p = dropArea.querySelector('p');
            if (h6) h6.textContent = 'Drag & Drop Gambar Produk';
            if (p) p.textContent = 'atau pilih sendiri';
        }
    };
}

// ==================== EVENT LISTENERS ====================
function setupEventListeners() {
    // Price formatting
    const priceInput = document.getElementById('price');
    if (priceInput) {
        priceInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value) {
                value = parseInt(value).toLocaleString('id-ID');
                e.target.value = value;
            }
        });
    }
    
    // Filter event listeners
    const filterCategory = document.getElementById('filterCategory');
    const filterStatus = document.getElementById('filterStatus');
    const searchInput = document.getElementById('searchProduct');
    
    if (filterCategory) {
        filterCategory.addEventListener('change', function() {
            console.log('Category filter:', this.value);
            filterProducts();
        });
    }
    
    if (filterStatus) {
        filterStatus.addEventListener('change', function() {
            console.log('Status filter:', this.value);
            filterProducts();
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                console.log('Search:', this.value);
                searchProducts();
            }
        });
        
        // Tambahkan search button
        const searchBtn = searchInput.nextElementSibling;
        if (searchBtn && searchBtn.tagName === 'BUTTON') {
            searchBtn.addEventListener('click', searchProducts);
        }
    }
    
    // Form submit
    const productForm = document.getElementById('productForm');
    if (productForm) {
        productForm.addEventListener('submit', handleFormSubmit);
    }
}

// ==================== FORM HANDLING ====================
function handleFormSubmit(e) {
    e.preventDefault();
    
    const priceInput = document.getElementById('price');
    const priceValue = priceInput.value.replace(/\./g, '');
    
    if (!priceValue || isNaN(priceValue)) {
        alert('Harga harus angka');
        priceInput.focus();
        return;
    }
    
    const formData = new FormData(this);
    formData.set('price', priceValue);
    
    // Tentukan action dari tombol yang diklik
    const submitter = e.submitter;
    if (submitter && submitter.name === 'action') {
        formData.set('action', submitter.value);
    } else {
        // Default action
        formData.set('action', 'save');
    }
    
    console.log('📤 Uploading product with action:', formData.get('action'));
    
    // Disable buttons
    const buttons = this.querySelectorAll('button[type="submit"]');
    buttons.forEach(btn => {
        btn.disabled = true;
        btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Processing...';
    });
    
    fetch(API_BASE + 'product_upload.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(text => {
        console.log('Upload response:', text);
        try {
            const data = JSON.parse(text);
            if (data.success) {
                showAlert('success', data.message || 'Produk berhasil disimpan!');
                // Reset form
                this.reset();
                removePreview();
                
                // Reload produk setelah 1 detik
                setTimeout(() => {
                    loadProducts();
                }, 1000);
            } else {
                showAlert('danger', data.message || 'Gagal menyimpan produk');
            }
        } catch(e) {
            console.error('JSON error:', e, 'Response:', text);
            showAlert('danger', 'Server error: ' + text.substring(0, 100));
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        showAlert('danger', 'Network error: ' + error.message);
    })
    .finally(() => {
        // Re-enable buttons
        buttons.forEach(btn => {
            btn.disabled = false;
            if (btn.name === 'action') {
                if (btn.value === 'save') {
                    btn.innerHTML = '<i class="bi bi-check-circle me-2"></i>Simpan Draft';
                } else if (btn.value === 'save_publish') {
                    btn.innerHTML = '<i class="bi bi-upload me-2"></i>Simpan & Publikasikan';
                }
            }
        });
    });
}

// ==================== PRODUCT TABLE FUNCTIONS ====================
function loadProducts(page = 1, category = '', status = '', search = '') {
    const tbody = document.getElementById('productTableBody');
    if (!tbody) {
        console.error('❌ Error: productTableBody element not found');
        return;
    }
    
    console.log('🔄 Loading products...', { page, category, status, search });
    
    // Show loading
    tbody.innerHTML = `
        <tr>
            <td colspan="9" class="text-center py-5">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
                <p class="mt-3 text-muted">Memuat data produk...</p>
            </td>
        </tr>
    `;
    
    // Build URL
    let url = `${API_BASE}get_products.php?page=${page}`;
    if (category && category !== '') url += `&category=${encodeURIComponent(category)}`;
    if (status && status !== '') url += `&status=${encodeURIComponent(status)}`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    
    console.log('📡 Fetching from:', url);
    
    fetch(url)
        .then(response => {
            console.log('📥 Response status:', response.status, response.statusText);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('✅ Data received, success:', data.success);
            
            if (data.success && Array.isArray(data.products)) {
                console.log(`📊 Found ${data.products.length} products`);
                updateProductTable(data.products);
                
                // Update pagination if needed
                if (data.pagination && data.pagination.pages > 1) {
                    updatePagination(data.pagination);
                } else {
                    document.getElementById('pagination').innerHTML = '';
                }
            } else {
                console.error('❌ Invalid data format or empty:', data);
                updateProductTable([]);
            }
        })
        .catch(error => {
            console.error('❌ Fetch error:', error);
            showErrorInTable(error.message);
        });
}

function updateProductTable(products) {
    const tbody = document.getElementById('productTableBody');
    if (!tbody) {
        console.error('❌ Error: productTableBody not found in updateProductTable');
        return;
    }
    
    console.log('📊 Updating table with', products?.length || 0, 'products');
    
    // Check if empty
    if (!products || products.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center py-5">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <h5 class="mt-3">Belum ada Produk</h5>
                    <p class="text-muted">Tambahkan produk pertama Anda</p>
                    <button class="btn btn-primary mt-2" onclick="document.querySelector('#productForm').scrollIntoView({behavior: 'smooth'})">
                        <i class="bi bi-plus-circle me-1"></i> Tambah Produk
                    </button>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    
    products.forEach((product, index) => {
        console.log(`Processing product ${index + 1}:`, product.product_name);
        
        // Handle image URL
        let imageUrl = '';
        if (product.image_url && product.image_url !== 'null') {
            if (product.image_url.startsWith('http')) {
                imageUrl = product.image_url;
            } else if (product.image_url.startsWith('assets/')) {
                imageUrl = '../' + product.image_url;
            } else {
                imageUrl = '../assets/uploads/products/' + product.image_url;
            }
        }
        
        // Image HTML
        const imageHtml = imageUrl 
            ? `<img src="${imageUrl}" 
                   style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;"
                   alt="${product.product_name}"
                   onerror="this.onerror=null; this.src='data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"50\" height=\"50\" viewBox=\"0 0 50 50\"><rect width=\"50\" height=\"50\" fill=\"%23f8f9fa\"/><text x=\"25\" y=\"25\" text-anchor=\"middle\" dy=\".3em\" fill=\"%236c757d\" font-size=\"10\">No Image</text></svg>';" />`
            : `<div style="width:50px;height:50px;background:#f8f9fa;border-radius:5px;display:flex;align-items:center;justify-content:center">
                  <i class="bi bi-image text-muted"></i>
               </div>`;
        
        // Status
        const isActive = product.status === 'active';
        const isDraft = product.status === 'draft';
        
        // Format numbers
        const priceFormatted = product.price_formatted || 'Rp 0';
        const revenueFormatted = product.revenue_formatted || 'Rp 0';
        const sold = product.sold || 0;
        const stock = product.stock || 0;
        
        // Stock badge color
        const stockClass = stock > 0 ? 'bg-success' : 'bg-danger';
        
        html += `
            <tr>
                <td>${product.id}</td>
                <td>${imageHtml}</td>
                <td>
                    <strong class="d-block">${product.product_name}</strong>
                    <small class="text-muted">${product.category}</small>
                    ${product.description ? `<small class="d-block text-muted mt-1">${product.description.substring(0, 60)}${product.description.length > 60 ? '...' : ''}</small>` : ''}
                </td>
                <td><strong>${priceFormatted}</strong></td>
                <td><span class="badge ${stockClass}">${stock}</span></td>
                <td><span class="badge bg-info">${sold}</span></td>
                <td><strong class="text-success">${revenueFormatted}</strong></td>
                <td>
                    ${isDraft 
                        ? `<span class="badge bg-secondary">Draft</span>`
                        : `
                        <div class="form-check form-switch">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   ${isActive ? 'checked' : ''}
                                   onchange="toggleProductStatus(${product.id}, this.checked)"
                                   id="switch-${product.id}">
                            <label class="form-check-label" for="switch-${product.id}">
                                <span class="badge ${isActive ? 'bg-success' : 'bg-warning'}">
                                    ${isActive ? 'Aktif' : 'Nonaktif'}
                                </span>
                            </label>
                        </div>
                        `
                    }
                </td>
                <td>
                    <div class="btn-group btn-group-sm" role="group">
                        <button class="btn ${isDraft ? 'btn-warning' : 'btn-outline-primary'}" 
                                onclick="editProduct(${product.id})"
                                title="Edit">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-outline-danger" 
                                onclick="deleteProduct(${product.id})"
                                title="Hapus">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    console.log('✅ Table updated successfully');
}

function showErrorInTable(message) {
    const tbody = document.getElementById('productTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = `
        <tr>
            <td colspan="9" class="text-center text-danger py-4">
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    <strong>Error loading products:</strong> ${message}
                    <div class="mt-2">
                        <button class="btn btn-sm btn-primary" onclick="loadProducts()">
                            <i class="bi bi-arrow-clockwise"></i> Coba Lagi
                        </button>
                        <button class="btn btn-sm btn-outline-secondary ms-2" onclick="location.reload()">
                            <i class="bi bi-arrow-repeat"></i> Refresh Halaman
                        </button>
                    </div>
                </div>
            </td>
        </tr>
    `;
}

function updatePagination(pagination) {
    const paginationEl = document.getElementById('pagination');
    if (!paginationEl || pagination.pages <= 1) {
        paginationEl.innerHTML = '';
        return;
    }
    
    let html = '';
    const currentPage = pagination.page;
    const totalPages = pagination.pages;
    
    // Previous button
    html += `
        <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" ${currentPage > 1 ? `onclick="loadProducts(${currentPage - 1}); return false;"` : ''}>
                <i class="bi bi-chevron-left"></i>
            </a>
        </li>
    `;
    
    // Page numbers - show max 5 pages
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    
    if (endPage - startPage < 4) {
        startPage = Math.max(1, endPage - 4);
    }
    
    for (let i = startPage; i <= endPage; i++) {
        html += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="loadProducts(${i}); return false;">${i}</a>
            </li>
        `;
    }
    
    // Next button
    html += `
        <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" ${currentPage < totalPages ? `onclick="loadProducts(${currentPage + 1}); return false;"` : ''}>
                <i class="bi bi-chevron-right"></i>
            </a>
        </li>
    `;
    
    paginationEl.innerHTML = html;
}

// ==================== FILTER & SEARCH ====================
function filterProducts() {
    const category = document.getElementById('filterCategory')?.value || '';
    const status = document.getElementById('filterStatus')?.value || '';
    console.log('🔍 Filtering by:', { category, status });
    loadProducts(1, category, status);
}

function searchProducts() {
    const search = document.getElementById('searchProduct')?.value || '';
    console.log('🔍 Searching for:', search);
    loadProducts(1, '', '', search);
}

// ==================== DEBUG UTILITIES ====================
function addDebugButton() {
    // Hanya di development
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        const debugBtn = document.createElement('button');
        debugBtn.className = 'btn btn-sm btn-warning position-fixed';
        debugBtn.style.cssText = 'bottom: 70px; right: 20px; z-index: 1000; font-size: 12px;';
        debugBtn.innerHTML = '<i class="bi bi-bug"></i> Debug';
        debugBtn.title = 'Debug Tools';
        debugBtn.onclick = function() {
            showDebugPanel();
        };
        document.body.appendChild(debugBtn);
    }
}

function showDebugPanel() {
    const existingPanel = document.getElementById('debugPanel');
    if (existingPanel) {
        existingPanel.remove();
        return;
    }
    
    const panel = document.createElement('div');
    panel.id = 'debugPanel';
    panel.style.cssText = `
        position: fixed;
        bottom: 110px;
        right: 20px;
        width: 300px;
        background: white;
        border: 2px solid #ffc107;
        border-radius: 8px;
        padding: 15px;
        z-index: 1001;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        font-family: monospace;
        font-size: 12px;
    `;
    
    panel.innerHTML = `
        <h6 class="mb-3"><i class="bi bi-bug me-2"></i>Debug Tools</h6>
        <div class="d-grid gap-2">
            <button class="btn btn-sm btn-info" onclick="testAPI()">
                <i class="bi bi-wifi"></i> Test API Connection
            </button>
            <button class="btn btn-sm btn-secondary" onclick="console.clear(); console.log('Console cleared')">
                <i class="bi bi-trash"></i> Clear Console
            </button>
            <button class="btn btn-sm btn-primary" onclick="loadProducts()">
                <i class="bi bi-arrow-clockwise"></i> Reload Products
            </button>
            <button class="btn btn-sm btn-success" onclick="simulateData()">
                <i class="bi bi-database"></i> Simulate Data
            </button>
            <hr>
            <button class="btn btn-sm btn-danger" onclick="document.getElementById('debugPanel').remove()">
                <i class="bi bi-x-circle"></i> Close
            </button>
        </div>
    `;
    
    document.body.appendChild(panel);
}

function testAPI() {
    console.log('🔍 Testing API connection...');
    fetch(API_BASE + 'get_products.php')
        .then(r => r.json())
        .then(data => {
            console.log('✅ API Response:', data);
            showAlert('success', `API OK! Found ${data.products?.length || 0} products`);
        })
        .catch(err => {
            console.error('❌ API Error:', err);
            showAlert('danger', 'API Error: ' + err.message);
        });
}

function simulateData() {
    const testData = [
        {
            id: 999,
            product_name: "TEST PRODUCT",
            description: "This is a test product",
            price: "100000",
            category: "Electronics",
            stock: 10,
            sold: 5,
            revenue: "500000",
            image_url: null,
            status: "active",
            price_formatted: "Rp 100.000",
            revenue_formatted: "Rp 500.000"
        }
    ];
    
    console.log('🧪 Simulating data:', testData);
    updateProductTable(testData);
    showAlert('info', 'Test data loaded (simulated)');
}

// ==================== INITIAL LOAD ====================
// Force initial load after 1 second
setTimeout(() => {
    console.log('🔄 Initial product load...');
    loadProducts();
}, 1000);
</script>

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://cdn.tiny.cloud/1/YOUR_API_KEY/tinymce/6/tinymce.min.js"></script>
  <script src="assets/js/pages/editor-tinymce.js"></script>


</body>

</html>