<?php
session_start();
require_once 'db.php';
require_once 'auth.php';

requireLogin();
$user = currentUser($conn); 

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Data Product - NiceAdmin</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
    /* Custom styles konsisten dengan Data User */
    .page-title {
      color: #012970;
      font-weight: 600;
    }
    
    .card-title {
      color: #4154f1;
      font-weight: 600;
    }
    
    .table th {
      background-color: #f8f9fa;
      font-weight: 600;
      color: #495057;
      border-top: none;
    }
    
    .badge {
      font-size: 0.75em;
      padding: 0.35em 0.65em;
    }
    
    .btn-group-sm .btn {
      padding: 0.25rem 0.5rem;
      font-size: 0.875rem;
    }
    
    .filter-section {
      background: #f8f9fa;
      border-radius: 8px;
      padding: 1rem;
      margin-bottom: 1.5rem;
    }
    
    .product-img {
      width: 50px;
      height: 50px;
      object-fit: cover;
      border-radius: 5px;
    }
    
    .no-data {
      min-height: 300px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item dropdown pe-3">
          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><h2><?= htmlspecialchars($user['username']) ?></h2></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Administrator</h6>
              <span>System Admin</span>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="tables-data-user.php">
                <i class="bi bi-person"></i>
                <span>Profile</span>
              </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="logout.html">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
              </a>
            </li>
          </ul>
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

     <!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

    <!-- Dashboard -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="index.php">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li>

    <!-- USERS -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="tables-data-user.php">
        <i class="bi bi-people"></i>
        <span>Users</span>
      </a>
    </li>

    <!-- PRODUCTS -->
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#products-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-box"></i>
        <span>Products</span>
        <i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="products-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
        <li>
          <a href="tables-data.php">
            <i class="bi bi-circle"></i><span>Data Barang</span>
          </a>
        </li>
        <li>
          <a href="forms-elements.php">
            <i class="bi bi-circle"></i><span>Upload Produk</span>
          </a>
        </li>
      </ul>
    </li>

    <!-- LOGOUT -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Logout</span>
      </a>
    </li>

  </ul>

</aside>
<!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1 class="page-title">Data Produk</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Data Produk</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Manajemen Produk</h5>
              <p>Atur semua produk yang ada.</p>

              <!-- Filter Section -->
              <div class="filter-section">
                <div class="row g-3 align-items-end">
                  <div class="col-md-3">
                    <label class="form-label">Kategori</label>
                    <select class="form-select" id="filterCategory">
                      <option value="">Semua Kategori</option>
                      <option value="Electronics">Elektronik</option>
                      <option value="Fashion">Fashion</option>
                      <option value="Sports">Olahraga</option>
                      <option value="Books">Buku</option>
                      <option value="Other">Lainnya</option>
                    </select>
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select class="form-select" id="filterStatus">
                      <option value="">Semua Status</option>
                      <option value="active">Aktif</option>
                      <option value="inactive">Inaktif</option>
                      <option value="draft">Draft</option>
                    </select>
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Cari Produk</label>
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Search by name..." id="searchProduct">
                      <button class="btn btn-outline-primary" type="button" onclick="searchProducts()">
                        <i class="bi bi-search"></i>
                      </button>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <button class="btn btn-primary mt-2" onclick="window.location.href='forms-elements.php'">
                      <i class="bi bi-plus-circle me-1"></i> Tambah Produk
                    </button>
                  </div>
                </div>
              </div><!-- End Filter Section -->

              <!-- Product Table -->
              <div class="table-responsive">
                <table class="table table-hover" id="productTable">
                  <thead>
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">Foto</th>
                      <th scope="col">Nama Produk</th>
                      <th scope="col">Kategori</th>
                      <th scope="col">Harga</th>
                      <th scope="col">Stok</th>
                      <th scope="col">Terjual</th>
                      <th scope="col">Status</th>
                      <th scope="col">Aksi</th>
                    </tr>
                  </thead>
                  <tbody id="productTableBody">
                    <!-- Data will be loaded by JavaScript -->
                    <tr>
                      <td colspan="9" class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                          <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading...</p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <!-- No Products Message -->
              <div id="noProducts" class="no-data" style="display: none;">
                <i class="bi bi-box display-1 text-muted"></i>
                <h5 class="mt-3">Tidak ada Produk</h5>
                <p class="text-muted">Tambahkan produk</p>
                <button class="btn btn-primary mt-2" onclick="window.location.href='forms-elements.php'">
                <i class="bi bi-plus-circle me-1"></i> Tambah Produk
                </button>
              </div>

              <!-- Pagination -->
              <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center" id="productPagination">
                  <!-- Pagination will be generated by JavaScript -->
                </ul>
              </nav>

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/pages/products.js"></script>


  <!-- Product Management JavaScript -->
<script>
const PRODUCT_API = '.../php/';

// ==================== LOAD PRODUCTS ====================
function loadProducts(page = 1, category = '', status = '', search = '') {
  const tbody = document.getElementById('productTableBody');
  const noProductsDiv = document.getElementById('noProducts');

  tbody.innerHTML = `
    <tr>
      <td colspan="9" class="text-center py-5">
        <div class="spinner-border text-primary"></div>
        <p class="mt-2">Loading...</p>
      </td>
    </tr>
  `;
  noProductsDiv.style.display = 'none';

  let url = `${PRODUCT_API}get_products.php?page=${page}`;
  if (category) url += `&category=${encodeURIComponent(category)}`;
  if (status) url += `&status=${encodeURIComponent(status)}`;
  if (search) url += `&search=${encodeURIComponent(search)}`;

  fetch(url)
    .then(res => res.json())
    .then(data => {
      if (data.success && data.products.length > 0) {
        updateProductTable(data.products);
        updateProductPagination(data.pagination);
      } else {
        showNoProducts();
      }
    })
    .catch(err => {
      console.error(err);
      showNoProducts();
    });
}

// ==================== TABLE RENDER ====================
function updateProductTable(products) {
  const tbody = document.getElementById('productTableBody');
  let html = '';

  products.forEach(p => {
    const imageHtml = p.image_url
      ? `<img src="../${p.image_url}" style="width:50px">`
      : `<i class="bi bi-image text-muted"></i>`;

    const statusBadge =
      p.status === 'active'
        ? `<span class="badge bg-success">Active</span>`
        : p.status === 'inactive'
        ? `<span class="badge bg-danger">Inactive</span>`
        : `<span class="badge bg-secondary">Draft</span>`;

    html += `
      <tr>
        <td>${p.id}</td>
        <td>${imageHtml}</td>
        <td><strong>${p.product_name}</strong></td>
        <td><span class="badge bg-info">${p.category}</span></td>
        <td>${p.price_formatted}</td>
        <td><span class="badge ${p.stock > 0 ? 'bg-success' : 'bg-danger'}">${p.stock}</span></td>
        <td><span class="badge bg-primary">${p.sold}</span></td>
        <td>${statusBadge}</td>
        <td>
          <button class="btn btn-sm btn-outline-primary" onclick="editProduct(${p.id})">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteProduct(${p.id})">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
}

// ==================== NO DATA ====================
function showNoProducts() {
  document.getElementById('productTableBody').innerHTML = '';
  document.getElementById('noProducts').style.display = 'flex';
}

// ==================== PAGINATION ====================
function updateProductPagination(pagination) {
  const el = document.getElementById('productPagination');
  if (!pagination || pagination.pages <= 1) {
    el.innerHTML = '';
    return;
  }

  let html = '';
  const p = pagination.page;

  html += `
    <li class="page-item ${p === 1 ? 'disabled' : ''}">
      <a class="page-link" href="#" onclick="loadProducts(${p - 1});return false;">&laquo;</a>
    </li>
  `;

  for (let i = 1; i <= pagination.pages; i++) {
    html += `
      <li class="page-item ${i === p ? 'active' : ''}">
        <a class="page-link" href="#" onclick="loadProducts(${i});return false;">${i}</a>
      </li>
    `;
  }

  html += `
    <li class="page-item ${p === pagination.pages ? 'disabled' : ''}">
      <a class="page-link" href="#" onclick="loadProducts(${p + 1});return false;">&raquo;</a>
    </li>
  `;

  el.innerHTML = html;
}

// ==================== ACTIONS ====================
function editProduct(id) {
  window.location.href = 'index.html?edit=' + id;
}

function deleteProduct(id) {
  if (!confirm('Delete product?')) return;

  fetch(PRODUCT_API + 'delete_product.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'id=' + id
  })
  .then(r => r.json())
  .then(d => {
    if (d.success) loadProducts();
    else alert(d.message);
  });
}

// ==================== FILTER ====================
function searchProducts() {
  loadProducts(
    1,
    filterCategory.value,
    filterStatus.value,
    searchProduct.value
  );
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
  filterCategory.onchange = searchProducts;
  filterStatus.onchange = searchProducts;
  searchProduct.onkeypress = e => e.key === 'Enter' && searchProducts();
  loadProducts();
});
</script>


</body>

</html>