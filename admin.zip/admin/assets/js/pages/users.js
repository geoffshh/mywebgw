/* assets/js/pages/users.js */
(function () {
  const { $ } = window.App || {};
  if (!$('#usersTable')) return;

  console.log('Users page loaded');

  // nanti tinggal isi fetch user
})();
