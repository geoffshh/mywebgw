/* assets/js/pages/editor-tinymce.js */
document.addEventListener('DOMContentLoaded', () => {
  if (!window.tinymce) return;
  if (!document.querySelector('textarea.tinymce-editor')) return;

  tinymce.init({
    selector: 'textarea.tinymce-editor',
    height: 500,
    plugins: 'lists link image code fullscreen',
    toolbar: 'undo redo | bold italic | bullist numlist | link image | code'
  });
});
