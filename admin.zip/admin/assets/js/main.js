/* assets/js/main.js */
(function () {
  'use strict';

  /* ===============================
     HELPERS
     =============================== */
  const $ = (s, o = document) => o.querySelector(s);
  const $$ = (s, o = document) => o.querySelectorAll(s);

  window.App = { $, $$ }; // expose helper global (AMAN)

  /* ===============================
     SIDEBAR TOGGLE
     =============================== */
  const sidebarBtn = $('.toggle-sidebar-btn');
  if (sidebarBtn) {
    sidebarBtn.addEventListener('click', () => {
      document.body.classList.toggle('toggle-sidebar');
    });
  }

  /* ===============================
     TOOLTIP
     =============================== */
  if (window.bootstrap) {
    $$('[data-bs-toggle="tooltip"]').forEach(el => {
      new bootstrap.Tooltip(el);
    });
  }

})();
