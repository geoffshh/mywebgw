<?php
require '../php/auth.php';
requireLogin();
$user = currentUser();
?>
