<?php
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login/index.html");
        exit;
    }
}

function currentUser(mysqli $conn) {
    $id = $_SESSION['user_id'];
    $q = mysqli_query($conn, "
        SELECT id, username, email, level
        FROM users WHERE id = $id
    ");
    return mysqli_fetch_assoc($q);
}
