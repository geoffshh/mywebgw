<?php
session_start();
require_once 'db.php';
require_once 'auth.php';

requireLogin();
$user = currentUser($conn); 

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Data User - NiceAdmin</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">
          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a>
        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">
          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a>
        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">
          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"> <h2><?= htmlspecialchars($user['username']) ?> </h2></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h2><?= htmlspecialchars($user['username']) ?></h2>
              <span>Web Designer</span>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>
          </ul>
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

   <!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

    <!-- Dashboard -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="index.php">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li>

    <!-- USERS -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="tables-data-user.php">
        <i class="bi bi-people"></i>
        <span>Users</span>
      </a>
    </li>

    <!-- PRODUCTS -->
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#products-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-box"></i>
        <span>Products</span>
        <i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="products-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
        <li>
          <a href="tables-data.php">
            <i class="bi bi-circle"></i><span>Data Barang</span>
          </a>
        </li>
        <li>
          <a href="forms-elements.php">
            <i class="bi bi-circle"></i><span>Upload Produk</span>
          </a>
        </li>
      </ul>
    </li>

    <!-- LOGOUT -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Logout</span>
      </a>
    </li>

  </ul>

</aside>
<!-- End Sidebar-->

      </li><!-- End Dashboard Nav -->

      <!-- MODIFIKASI INI: Tambah menu Users -->
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#users-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-people"></i><span>Users</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="users-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
          <li>
            <a href="tables-data-user.html" class="active">
              <i class="bi bi-circle"></i><span>Data User</span>
            </a>
          </li>
          <li>
            <a href="users-profile.php">
              <i class="bi bi-circle"></i><span>User Profile</span>
            </a>
          </li>
        </ul>
      </li><!-- End Users Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#products-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-box"></i><span>Products</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="products-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
          <li>
            <a href="tables-data.html">
              <i class="bi bi-circle"></i><span>Data Barang</span>
            </a>
          </li>
          <li>
            <a href="forms-eements.html>
              <i class="bi bi-circle"></i><span>Upload Produk</span>
            </a>
          </li>
        </ul>
   

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Data User</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item active">Data User</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Data Pengguna Sistem</h5>
              <p>Kelola data pengguna yang terdaftar dalam sistem.</p>

              <!-- Filter dan Tools -->
              <div class="row mb-3">
                <div class="col-md-3">
                  <select class="form-select" id="filterRole">
                    <option value="">Semua Role</option>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                    <option value="seller">Seller</option>
                  </select>
                </div>
                <div class="col-md-3">
                  <select class="form-select" id="filterStatus">
                    <option value="">Semua Status</option>
                    <option value="active">Aktif</option>
                    <option value="inactive">Nonaktif</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Cari user..." id="searchUser">
                    <button class="btn btn-outline-primary" type="button" onclick="searchUsers()">
                      <i class="bi bi-search"></i>
                    </button>
                    <button class="btn btn-success" type="button" onclick="addUser()">
                      <i class="bi bi-plus-circle"></i> Tambah User
                    </button>
                  </div>
                </div>
              </div>

              <!-- Tabel Data User -->
              <div class="table-responsive">
                <table class="table table-striped table-hover" id="userTable">
                  <thead>
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">Foto</th>
                      <th scope="col">Nama</th>
                      <th scope="col">Email</th>
                      <th scope="col">Role</th>
                      <th scope="col">Status</th>
                      <th scope="col">Bergabung</th>
                      <th scope="col">Aksi</th>
                    </tr>
                  </thead>
                  <tbody id="userTableBody">
                    <!-- Data akan diisi oleh JavaScript -->
                    <tr>
                      <td colspan="8" class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                          <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Memuat data user...</p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <!-- Pagination -->
              <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center" id="userPagination">
                  <!-- Pagination akan di-generate via JavaScript -->
                </ul>
              </nav>

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/pages/users.js"></script>


  <!-- Data User JavaScript -->
  <script>
  // ==================== KONFIGURASI ====================
  const USER_API_BASE = '.../php/';

  // ==================== FUNGSI UTAMA ====================
  function loadUsers(page = 1, role = '', status = '', search = '') {
    const tbody = document.getElementById('userTableBody');
    if (!tbody) return;
    
    // Show loading
    tbody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-4">
          <div class="spinner-border text-primary"></div>
          <p class="mt-2">Memuat data user...</p>
        </td>
      </tr>
    `;
    
    // Fetch data dari API
    fetch(USER_API_BASE + 'get_users.php?page=' + page + 
          '&role=' + encodeURIComponent(role) + 
          '&status=' + encodeURIComponent(status) + 
          '&search=' + encodeURIComponent(search))
      .then(response => response.json())
      .then(data => {
        if (data.success && Array.isArray(data.users)) {
          updateUserTable(data.users);
          updateUserPagination(data.pagination);
        } else {
          showNoUsers();
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showNoUsers();
      });
  }

  function updateUserTable(users) {
    const tbody = document.getElementById('userTableBody');
    if (!tbody) return;
    
    if (!users || users.length === 0) {
      showNoUsers();
      return;
    }
    
    let html = '';
    
    users.forEach(user => {
      
      // Format tanggal
      const joinDate = new Date(user.created_at).toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
      
      html += `
        <tr>
          <td>${user.id}</td>
          <td>${photoHtml}</td>
          <td>
            <strong>${user.username}</strong>
            ${user.full_name ? `<br><small>${user.full_name}</small>` : ''}
          </td>
          <td>${user.email}</td>
          <td>${joinDate}</td>
          <td>
            <div class="btn-group btn-group-sm" role="group">
              <button class="btn btn-outline-primary" onclick="editUser(${user.id})" title="Edit">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-outline-danger" onclick="deleteUser(${user.id})" title="Hapus">
                <i class="bi bi-trash"></i>
              </button>
              <button class="btn btn-outline-info" onclick="viewUser(${user.id})" title="Detail">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    });
    
    tbody.innerHTML = html;
  }

  function showNoUsers() {
    const tbody = document.getElementById('userTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-5">
          <i class="bi bi-people display-1 text-muted"></i>
          <h5 class="mt-3">Belum ada User</h5>
          <p class="text-muted">Tambahkan user pertama Anda</p>
          <button class="btn btn-primary mt-2" onclick="addUser()">
            <i class="bi bi-plus-circle"></i> Tambah User
          </button>
        </td>
      </tr>
    `;
  }

  function updateUserPagination(pagination) {
    const paginationEl = document.getElementById('userPagination');
    if (!paginationEl || !pagination || pagination.pages <= 1) {
      paginationEl.innerHTML = '';
      return;
    }
    
    let html = '';
    
    // Previous
    html += `
      <li class="page-item ${pagination.page <= 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" ${pagination.page > 1 ? `onclick="loadUsers(${pagination.page - 1}); return false;"` : ''}>
          <i class="bi bi-chevron-left"></i>
        </a>
      </li>
    `;
    
    // Pages
    for (let i = 1; i <= pagination.pages; i++) {
      html += `
        <li class="page-item ${i === pagination.page ? 'active' : ''}">
          <a class="page-link" href="#" onclick="loadUsers(${i}); return false;">${i}</a>
        </li>
      `;
    }
    
    // Next
    html += `
      <li class="page-item ${pagination.page >= pagination.pages ? 'disabled' : ''}">
        <a class="page-link" href="#" ${pagination.page < pagination.pages ? `onclick="loadUsers(${pagination.page + 1}); return false;"` : ''}>
          <i class="bi bi-chevron-right"></i>
        </a>
      </li>
    `;
    
    paginationEl.innerHTML = html;
  }

  // ==================== FUNGSI AKSI ====================
  function addUser() {
    alert('Fitur tambah user akan datang!');
    // Redirect ke form tambah user
    // window.location.href = 'user-form.html';
  }

  function editUser(id) {
    if (confirm('Edit user ID ' + id + '?')) {
      // Redirect ke form edit
      // window.location.href = 'user-form.html?id=' + id;
      alert('Edit user ID: ' + id);
    }
  }

  function deleteUser(id) {
    if (confirm('Hapus user ID ' + id + '?')) {
      fetch(USER_API_BASE + 'delete_user.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert('User berhasil dihapus');
          loadUsers();
        } else {
          alert('Gagal menghapus: ' + data.message);
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Network error');
      });
    }
  }

  function viewUser(id) {
    // Redirect ke detail user
    // window.location.href = 'user-detail.html?id=' + id;
    alert('View user ID: ' + id);
  }

  function searchUsers() {
    const search = document.getElementById('searchUser').value;
    const role = document.getElementById('filterRole').value;
    const status = document.getElementById('filterStatus').value;
    loadUsers(1, role, status, search);
  }

  // ==================== EVENT LISTENERS ====================
  document.addEventListener('DOMContentLoaded', function() {
    // Setup filter listeners
    document.getElementById('filterRole')?.addEventListener('change', searchUsers);
    document.getElementById('filterStatus')?.addEventListener('change', searchUsers);
    document.getElementById('searchUser')?.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') searchUsers();
    });
    
    // Initial load
    loadUsers();
    
    // Prevent simple-datatables
    const table = document.getElementById('userTable');
    if (table) {
      table.classList.remove('datatable');
    }
  });
  </script>

</body>

</html>