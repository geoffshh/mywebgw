// js.js - Form validation and password toggle
document.addEventListener('DOMContentLoaded', function() {
    // Password toggle functionality
    const passwordToggle = document.getElementById('passwordToggle');
    const passwordInput = document.getElementById('password');
    
    if (passwordToggle && passwordInput) {
        passwordToggle.addEventListener('click', function() {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.querySelector('.eye-icon').textContent = '👁️‍🗨️';
            } else {
                passwordInput.type = 'password';
                this.querySelector('.eye-icon').textContent = '👁️';
            }
        });
    }
    
    // Form validation for login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const username = document.getElementById('username');
            const password = document.getElementById('password');
            let isValid = true;
            
            // Clear previous errors
            document.querySelectorAll('.error-message').forEach(el => {
                el.textContent = '';
                el.style.display = 'none';
            });
            
            // Validate username
            if (!username.value.trim()) {
                const errorEl = document.getElementById('usernameError') || createErrorElement(username);
                errorEl.textContent = 'Username harus diisi';
                errorEl.style.display = 'block';
                isValid = false;
            }
            
            // Validate password
            if (!password.value.trim()) {
                const errorEl = document.getElementById('passwordError') || createErrorElement(password);
                errorEl.textContent = 'Password harus diisi';
                errorEl.style.display = 'block';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // Form validation for registration
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const username = document.getElementById('username');
            const password = document.getElementById('password');
            const email = document.getElementById('email');
            const noTelp = document.getElementById('no_telp');
            let isValid = true;
            
            // Clear previous errors
            document.querySelectorAll('.error-message').forEach(el => {
                el.textContent = '';
                el.style.display = 'none';
            });
            
            // Validate username
            if (!username.value.trim()) {
                const errorEl = document.getElementById('usernameError') || createErrorElement(username);
                errorEl.textContent = 'Username harus diisi';
                errorEl.style.display = 'block';
                isValid = false;
            }
            
            // Validate password
            if (!password.value.trim()) {
                const errorEl = document.getElementById('passwordError') || createErrorElement(password);
                errorEl.textContent = 'Password harus diisi';
                errorEl.style.display = 'block';
                isValid = false;
            } else if (password.value.length < 6) {
                const errorEl = document.getElementById('passwordError') || createErrorElement(password);
                errorEl.textContent = 'Password minimal 6 karakter';
                errorEl.style.display = 'block';
                isValid = false;
            }
            
            // Validate email
            if (!email.value.trim()) {
                const errorEl = document.getElementById('emailError') || createErrorElement(email);
                errorEl.textContent = 'Email harus diisi';
                errorEl.style.display = 'block';
                isValid = false;
            } else if (!isValidEmail(email.value)) {
                const errorEl = document.getElementById('emailError') || createErrorElement(email);
                errorEl.textContent = 'Format email tidak valid';
                errorEl.style.display = 'block';
                isValid = false;
            }
            
            // Validate phone number
            if (!noTelp.value.trim()) {
                const errorEl = document.getElementById('phoneError') || createErrorElement(noTelp);
                errorEl.textContent = 'Nomor telepon harus diisi';
                errorEl.style.display = 'block';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // Helper functions
    function createErrorElement(inputElement) {
        const formGroup = inputElement.closest('.form-group');
        const errorEl = document.createElement('span');
        errorEl.className = 'error-message';
        formGroup.appendChild(errorEl);
        return errorEl;
    }
    
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Show success message if exists in URL
    const urlParams = new URLSearchParams(window.location.search);
    const successMessage = urlParams.get('success');
    if (successMessage) {
        alert(successMessage);
    }


	// Di js.js
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        // Pastikan semua form menggunakan POST
        if (!form.getAttribute('method')) {
            form.setAttribute('method', 'POST');
        }
        
        // Validasi sebelum submit
        form.addEventListener('submit', function(e) {
            // Cek jika method GET (mencegah data muncul di URL)
            if (this.getAttribute('method').toUpperCase() === 'GET') {
                e.preventDefault();
                alert('Form harus menggunakan method POST');
                return false;
            }
        });
    });
});
});